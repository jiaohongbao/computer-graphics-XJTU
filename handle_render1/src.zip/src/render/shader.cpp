#include "rasterizer_renderer.h"
#include "../utils/math.hpp"
#include <cstdio>

#ifdef _WIN32
#undef min
#undef max
#endif

using Eigen::Vector3f;
using Eigen::Vector4f;

// vertex shader
VertexShaderPayload vertex_shader(const VertexShaderPayload& payload)
{
    VertexShaderPayload output_payload = payload;

    output_payload.viewport_position = Uniforms::MVP * output_payload.world_position;

    Eigen::Matrix<float, 4, 4> factor = Eigen::Matrix4f::Identity();
    factor(0, 0)                      = Uniforms::width / 2.0f;
    factor(1, 1)                      = Uniforms::height / 2.0f;
    factor(0, 3)                      = Uniforms::width / 2.0f;
    factor(1, 3)                      = Uniforms::height / 2.0f;

    output_payload.viewport_position = factor * output_payload.viewport_position;

    Vector3f n = (Uniforms::inv_trans_M.topLeftCorner<3, 3>() * payload.normal).normalized();

    output_payload.normal = n;

    return output_payload;
}

Vector3f phong_fragment_shader(const FragmentShaderPayload& payload, const GL::Material& material,
                               const std::list<Light>& lights, const Camera& camera)
{
    Vector3f ka = material.ambient, kd = material.diffuse, ks = material.specular;

    float shininess = material.shininess;
    Vector3f result;
    result << 0, 0, 0;
    for (auto iterator = lights.begin(); iterator != lights.end(); iterator++) {
        Vector3f direcion_of_camera = (camera.position - payload.world_pos).normalized();
        Vector3f direction_of_light = (iterator->position - payload.world_pos).normalized();

        if (direcion_of_camera.norm() == 0.0f || direction_of_light.norm() == 0.0f) {
            continue;
        }

        Vector3f half = (direction_of_light + direcion_of_camera).normalized();

        float distance = (iterator->position - payload.world_pos).squaredNorm();

        float reducing = iterator->intensity / (distance + 1e-10f);

        float specular_intensity = std::max(half.dot(payload.world_normal.normalized()), 0.0f);

        float diffuse_intensity =
            std::max(direction_of_light.dot(payload.world_normal.normalized()), 0.f);

        Vector3f specular = ks * std::pow(specular_intensity, shininess) * reducing;

        result = ka + kd * diffuse_intensity * reducing + specular;
    }
    //result *= 255.0f;
    result = result.cwiseMax(0.0f).cwiseMin(1.0f) * 255.0f;
    return result;
}
// ka,kd,ks can be got from material.ambient,material.diffuse,material.specular

// set ambient light intensity

// Light Direction

// View Direction

// Half Vector

// Light Attenuation

// Ambient

// Diffuse

// Specular

// set rendering result max threshold to 255
