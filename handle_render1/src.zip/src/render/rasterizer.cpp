#include <array>
#include <limits>
#include <tuple>
#include <vector>
#include <algorithm>
#include <cmath>
#include <mutex>

#include <Eigen/Core>
#include <Eigen/Geometry>
#include <spdlog/spdlog.h>

#include "rasterizer.h"
#include "triangle.h"
#include "../utils/math.hpp"

using Eigen::Matrix4f;
using Eigen::Vector2i;
using Eigen::Vector3f;
using Eigen::Vector4f;
using std::fill;
using std::tuple;

void Rasterizer::worker_thread()
{
    while (true) {
        VertexShaderPayload payload;
        Triangle triangle;
        {
            // printf("vertex_finish = %d\n vertex_shader_output_queue.size = %ld\n",
            // Context::vertex_finish, Context::vertex_shader_output_queue.size());
            if (Context::vertex_finish && Context::vertex_shader_output_queue.empty()) {
                Context::rasterizer_finish = true;
                return;
            }
            if (Context::vertex_shader_output_queue.size() < 3) {
                continue;
            }
            std::unique_lock<std::mutex> lock(Context::vertex_queue_mutex);
            if (Context::vertex_shader_output_queue.size() < 3) {
                continue;
            }
            for (size_t vertex_count = 0; vertex_count < 3; vertex_count++) {
                payload = Context::vertex_shader_output_queue.front();
                Context::vertex_shader_output_queue.pop();
                if (vertex_count == 0) {
                    triangle.world_pos[0]    = payload.world_position;
                    triangle.viewport_pos[0] = payload.viewport_position;
                    triangle.normal[0]       = payload.normal;
                } else if (vertex_count == 1) {
                    triangle.world_pos[1]    = payload.world_position;
                    triangle.viewport_pos[1] = payload.viewport_position;
                    triangle.normal[1]       = payload.normal;
                } else {
                    triangle.world_pos[2]    = payload.world_position;
                    triangle.viewport_pos[2] = payload.viewport_position;
                    triangle.normal[2]       = payload.normal;
                }
            }
        }
        rasterize_triangle(triangle);
    }
}

float sign(Eigen::Vector2f p1, Eigen::Vector2f p2, Eigen::Vector2f p3)
{
    return (p1.x() - p3.x()) * (p2.y() - p3.y()) - (p2.x() - p3.x()) * (p1.y() - p3.y());
}

bool Rasterizer::inside_triangle(int x, int y, const Eigen::Vector4f* vertices)
{
    float x1 = vertices[0].x(), y1 = vertices[0].y();
    float x2 = vertices[1].x(), y2 = vertices[1].y();
    float x3 = vertices[2].x(), y3 = vertices[2].y();
    // calculate vector's cross produce
    float CP1 = (x2 - x1) * (y - y1) - (y2 - y1) * (x - x1);
    float CP2 = (x3 - x2) * (y - y2) - (y3 - y2) * (x - x2);

    float CP3 = (x1 - x3) * (y - y3) - (y1 - y3) * (x - x3);
    if (CP1 >= 0 && CP2 >= 0 && CP3 >= 0) {
        return true;
    } else {
        return false;
    }
}

std::tuple<float, float, float> Rasterizer::compute_barycentric_2d(float x, float y,
                                                                   const Eigen::Vector4f* v)
{
    Eigen::Matrix<float, 3, 1> P;
    P << 1, x, y;
    Eigen::Matrix<float, 3, 3> Triangle;

    Triangle << 1, 1, 1, v[0].x(), v[1].x(), v[2].x(), v[0].y(), v[1].y(), v[2].y();

    Triangle = Triangle.inverse();

    Eigen::Matrix<float, 3, 1> Answer;

    Answer = Triangle * P;

    return {Answer(0, 0), Answer(1, 0), Answer(2, 0)};
}

// 对顶点的某一属性插值
Vector3f Rasterizer::interpolate(float alpha, float beta, float gamma, const Eigen::Vector3f& vert1,
                                 const Eigen::Vector3f& vert2, const Eigen::Vector3f& vert3,
                                 const Eigen::Vector3f& weight, const float& Z)
{
    Vector3f interpolated_res;
    for (int i = 0; i < 3; i++) {
        interpolated_res[i] = alpha * vert1[i] / weight[0] + beta * vert2[i] / weight[1] +
                              gamma * vert3[i] / weight[2];
    }
    interpolated_res *= Z;
    return interpolated_res;
}


/*
tuple<float,float> f_min_max(float a,float b,float c){
  float min=a,max=a;
  if(b<min){
    min=b;
  }
  if(c<min){
    min=c;
  }
  if(b>max){
    max=b;
  }
  if(c>max){
    max=c;
  }
  return{min,max};
}
*/
void Rasterizer::rasterize_triangle(Triangle& t)
{
  // these lines below are just for compiling and can be deleted
    //(void)t;
    //FragmentShaderPayload payload;
    // these lines above are just for compiling and can be deleted

    // if current pixel is in current triange:
    // 1. interpolate depth(use projection correction algorithm)
    // 2. interpolate vertex positon & normal(use function:interpolate())
    // 3. push primitive into fragment queue
    //
    //
    //
    //FragmentShaderPayload payload;
    






/*
  auto [minx,maxx]=f_min_max(t.viewport_pos[0].x(),t.viewport_pos[1].x(),t.viewport_pos[2].x()); 
    auto [miny,maxy]=f_min_max(t.viewport_pos[0].y(),t.viewport_pos[1].y(),t.viewport_pos[2].y());
 
*/
float minx = std::min({t.viewport_pos[0].x(), t.viewport_pos[1].x(), t.viewport_pos[2].x()});
    float maxx = std::max({t.viewport_pos[0].x(), t.viewport_pos[1].x(), t.viewport_pos[2].x()});
    float miny = std::min({t.viewport_pos[0].y(), t.viewport_pos[1].y(), t.viewport_pos[2].y()});
    float maxy = std::max({t.viewport_pos[0].y(), t.viewport_pos[1].y(), t.viewport_pos[2].y()});
  




    //printf("t.viewport_pos[0].w() = %f, t.viewport_pos[1].w() = %f, t.viewport_pos[2].w() = %f\n",
       //t.viewport_pos[0].w(), t.viewport_pos[1].w(), t.viewport_pos[2].w());
    for (int i = static_cast<int>(std::floor(minx)); i <= static_cast<int>(std::ceil(maxx)); i++) {
        for (int j = static_cast<int>(std::floor(miny)); j <= static_cast<int>(std::ceil(maxy)); j++) {
            FragmentShaderPayload payload;
            
            if (inside_triangle(float(i) , float(j) , t.viewport_pos))
            {


                auto [alpha, beta, gamma] = compute_barycentric_2d(float(i),float(j), t.viewport_pos);


                Vector4f point[3];
                /*
                point[0]<<t.world_pos[0].x(),t.world_pos[0].y(),t.world_pos[0].z(),1;
                point[1]<<t.world_pos[1].x(),t.world_pos[1].y(),t.world_pos[1].z(),1;
                point[2]<<t.world_pos[2].x(),t.world_pos[2].y(),t.world_pos[2].z(),1;
                */
                point[0]=t.viewport_pos[0];
                point[1]=t.viewport_pos[1];
                point[2]=t.viewport_pos[2];


          
                float z_depth_of_point[3];
                z_depth_of_point[0]=t.viewport_pos[0].w();
                z_depth_of_point[1]=t.viewport_pos[1].w();
                z_depth_of_point[2]=t.viewport_pos[2].w();

          
          //auto Zt=1/(alpha/z_depth_of_point[0]+beta/z_depth_of_point[1]+gamma/z_depth_of_point[2]);
          //auto It=(alpha*point[0].z()/z_depth_of_point[0]+beta*point[1].z()/z_depth_of_point[1]+gamma*point[2].z()/z_depth_of_point[2])*Zt;



                float It = alpha * t.viewport_pos[0].z() + beta  * t.viewport_pos[1].z() + gamma * t.viewport_pos[2].z();
                
                
               
                
                payload.world_pos = interpolate(alpha,beta,gamma,t.world_pos[0].head<3>(),t.world_pos[1].head<3>(),t.world_pos[2].head<3>(),{z_depth_of_point[0], z_depth_of_point[1], z_depth_of_point[2]},It);
                payload.world_normal=interpolate(alpha,beta,gamma,t.normal[0],t.normal[1],t.normal[2],{z_depth_of_point[0], z_depth_of_point[1], z_depth_of_point[2]},It);

                
                payload.x=i;
                payload.y=j;
                payload.depth=It;



                std::unique_lock<std::mutex> lock(Context::rasterizer_queue_mutex);
                Context::rasterizer_output_queue.push(payload);
            }
            
        }
    }
}
